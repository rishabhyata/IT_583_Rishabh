﻿using System;

namespace Lab04
{
    class Lab4
    {
        static void Main(string[] args)
        {
            int a = 1, b = 3, c = 5;
            double x = 2.2, y = 4.4, z = 6.6, ans;

            ans = Average(a, b);
            Console.WriteLine("\naverage(a,b) = " + ans);

            ans = Average(a, b, c);
            Console.WriteLine("\naverage(a,b,c) = " + ans);

            ans = Average(x, y);
            Console.WriteLine("\naverage(x,y) = " + ans);

            ans = Average(x, y, z);
            Console.WriteLine("\naverage(x,y,z) = " + ans);
        }

        public static double average(int n1, int n2)
        {
            return (n1 + n2) / 2.0;
        }

        // Overloaded method Definition(s) here

        private static double Average(double n1, double n2, double n3)
        {
            return (n1 + n2 + n3) / 3.0;
        }

        private static double Average(double n1, double n2)
        {
            return (n1 + n2) / 2.0;
        }

        private static double Average(int n1, int n2, int n3)
        {
            return (n1 + n2 + n3) / 3.0;
        }
    }
}
