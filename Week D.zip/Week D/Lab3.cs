﻿using System;

public class Lab09
{
    public static void Main(string[] args)
    {
        double curBal = 45.32;
        double amount;
        Console.Write("Please enter a amount to update account by $");
        amount = Convert.ToDouble(Console.ReadLine());
        Console.Write("\n");
        Console.Write("Customer’s balance (before transaction) = $");
        Console.WriteLine(curBal + "\n");
        Console.Write("Requested update amount = $");
        Console.WriteLine(amount + "\n");
        double actAmount;
        actAmount = transaction(curBal, amount);
        curBal += actAmount;
        Console.Write("Actual update amount = $");
        Console.WriteLine(actAmount + "\n");
        Console.Write("Customer’s balance (after transaction) = $");
        Console.WriteLine(curBal + "\n");
        Console.WriteLine("\nThank you and good-bye!\n");
    }
    public static double transaction(double bal, double amount)
    {
        // Write your code here ...
        if (amount >= 0) //it is a deposit
        {
            return amount;
        }
        else //its a withdrawal
        {
            if (bal + amount < 0) //if balance goes below 0, return the amount that will lead to 0 balance
            {
                return -bal;
            }
            else
            {
                return amount;
            }
        }
    }
}