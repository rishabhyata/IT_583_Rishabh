$(document).ready(function () {
    //to get focus on arrival date field
    document.getElementById("arrival_date").focus();
    var emailPattern = /\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,4}\b/;
    var flag = 1;
    $( "#reservation_form" ).submit(function( event ) {
        //to check arrival date field is empty or not
        if(document.getElementById("arrival_date").value=="" ){
            document.getElementById("arrival_date_info").textContent="This field is required";  
            flag = 0;
      }
      //to check nights field is empty or not
      if(document.getElementById("nights").value=="" ){
        document.getElementById("nights_info").textContent="This field is required";  
        flag = 0;
    }
    //to check name field is empty or not
        if(document.getElementById("name").value == "") {
        document.getElementById("name_info").textContent = "This field is required";
            flag = 0;
    }
    //to check email field is empty or not
    if(document.getElementById("email").value=="" ){
        document.getElementById("email_info").textContent="This field is required";  
        flag = 0;
    }
    //to check phone field is empty or not
    if(document.getElementById("phone").value=="" ){
        document.getElementById("phone_info").textContent="This field is required";  
        flag = 0;
    }
    //to check nights feild is numeric or not
    if(isNaN(document.getElementById("nights").value)){
        document.getElementById("nights_info").textContent="This field must be numeric";
        flag =  0 ;
      }
    //to check email is valid or not using the emailpattern varaible
      if(!emailPattern.test(document.getElementById("email").value)){
        document.getElementById("email_info").textContent="Must be a valid email address";  
        flag = 0;
      }
      //if any of the field is not correct then prevent form submitting
      if(flag == 0)
      event.preventDefault();
        
    });

});
// end ready