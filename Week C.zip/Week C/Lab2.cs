﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab02
{
    class Program
    {
        static void Main(string[] args)
        {
            int glasses = -1;
            int glare = -1;
            double cost = 0;
            Console.WriteLine("What kind of glasses would you like: ");
            while (!(glasses == 1 || glasses == 2))
            {
                Console.Write("1 -> prescription, 2 -> non-prescription : ");
                glasses = Convert.ToInt32(Console.ReadLine());
            }
            Console.WriteLine("\nWhat kind of caoting would you like: ");
            while (!(glare == 1 || glare == 2))
            {
                Console.Write("1 -> anti-glare, 2 -> brown tint: ");
                glare = Convert.ToInt32(Console.ReadLine());
            }
            if (glasses == 1)
                cost += 40.00;
            else
                cost += 25.00;
            if (glare == 1)
                cost += 12.50;
            else
                cost += 9.99;
            Console.WriteLine("\nThe total cost is ${0}", cost);
            Console.ReadLine();
        }
    }
}